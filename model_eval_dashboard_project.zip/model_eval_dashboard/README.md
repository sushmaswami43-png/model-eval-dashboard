# Evaluation Dashboard for Model Cards

Trains Logistic Regression and Random Forest on an imbalanced breast-cancer screening
dataset, then builds a dashboard (confusion matrices, ROC curves, metrics table).

    pip install -r requirements.txt
    python main.py

Outputs (in `outputs/`): `dashboard.png` (static), `dashboard.html` (interactive,
open in any browser, drag the threshold slider), `metrics.csv`.

Layout: `src/config.py` settings, `data.py` loading/split, `models.py` classifiers,
`evaluate.py` metrics, `dashboard.py` visuals, `main.py` entry point.
