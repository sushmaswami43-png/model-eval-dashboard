"""Train two classifiers on an imbalanced dataset and build the evaluation dashboard.

Run:  python main.py
"""
from src.config import OUTPUT_DIR
from src.dashboard import save_interactive_dashboard, save_static_dashboard
from src.data import load_imbalanced_breast_cancer, split
from src.evaluate import cross_validated_auc, evaluate_model, metrics_table
from src.models import build_models


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)

    X, y = load_imbalanced_breast_cancer()
    X_train, X_test, y_train, y_test = split(X, y)
    print(f"Samples: {len(y)} | malignant share: {y.mean():.1%} "
          f"| train {len(y_train)} / test {len(y_test)} "
          f"({int(y_test.sum())} malignant in test)")

    results = []
    for name, model in build_models().items():
        model.fit(X_train, y_train)
        results.append(evaluate_model(name, model, X_test, y_test))
        mean, std = cross_validated_auc(model, X, y)
        print(f"{name}: 5-fold CV ROC-AUC = {mean:.3f} +/- {std:.3f}")

    table = metrics_table(results)
    print("\n", table.to_string(), "\n")
    for r in results:
        tn, fp, fn, tp = r.confusion.ravel()
        print(f"{r.name}: TN={tn} FP={fp} FN={fn} TP={tp}")

    table.to_csv(OUTPUT_DIR / "metrics.csv")
    save_static_dashboard(results, table, OUTPUT_DIR / "dashboard.png")
    subtitle = (f"Wisconsin Diagnostic Breast Cancer data, malignant = positive class "
                f"({y.mean():.0%} prevalence). Test set: {len(y_test)} patients.")
    save_interactive_dashboard(results, y_test, subtitle, OUTPUT_DIR / "dashboard.html")
    print(f"\nSaved dashboard.png, dashboard.html, metrics.csv to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
