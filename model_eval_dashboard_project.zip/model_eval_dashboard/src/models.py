"""Model definitions. Class imbalance is handled with cost-sensitive learning."""
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .config import RANDOM_STATE


def build_models() -> dict[str, Pipeline]:
    """Return untrained models; class_weight reweights the loss toward the rare class."""
    return {
        "Logistic Regression": Pipeline([
            ("scale", StandardScaler()),
            ("clf", LogisticRegression(
                class_weight="balanced", max_iter=1000, random_state=RANDOM_STATE)),
        ]),
        "Random Forest": Pipeline([
            ("clf", RandomForestClassifier(
                n_estimators=300, class_weight="balanced_subsample",
                random_state=RANDOM_STATE, n_jobs=-1)),
        ]),
    }
