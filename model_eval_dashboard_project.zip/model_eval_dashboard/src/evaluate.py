"""Metric computation for fitted models."""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.metrics import (average_precision_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import StratifiedKFold, cross_val_score

from .config import CV_FOLDS, RANDOM_STATE


@dataclass
class ModelResult:
    name: str
    y_score: np.ndarray        # predicted probability of the positive class
    y_pred: np.ndarray         # hard labels at the default 0.5 threshold
    metrics: dict
    confusion: np.ndarray      # [[TN, FP], [FN, TP]]
    fpr: np.ndarray
    tpr: np.ndarray


def evaluate_model(name, model, X_test, y_test) -> ModelResult:
    y_score = model.predict_proba(X_test)[:, 1]
    y_pred = (y_score >= 0.5).astype(int)
    fpr, tpr, _ = roc_curve(y_test, y_score)
    metrics = {
        "Precision": precision_score(y_test, y_pred),
        "Recall": recall_score(y_test, y_pred),
        "F1-score": f1_score(y_test, y_pred),
        "ROC-AUC": roc_auc_score(y_test, y_score),
        "PR-AUC": average_precision_score(y_test, y_score),
    }
    return ModelResult(name, y_score, y_pred, metrics,
                       confusion_matrix(y_test, y_pred), fpr, tpr)


def cross_validated_auc(model, X, y) -> tuple[float, float]:
    """Mean and std of ROC-AUC over stratified folds (guards against a lucky split)."""
    cv = StratifiedKFold(CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    scores = cross_val_score(model, X, y, cv=cv, scoring="roc_auc")
    return scores.mean(), scores.std()


def metrics_table(results: list[ModelResult]) -> pd.DataFrame:
    return pd.DataFrame({r.name: r.metrics for r in results}).T.round(3)
