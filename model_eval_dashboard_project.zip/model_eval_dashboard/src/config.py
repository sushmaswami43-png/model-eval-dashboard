"""Central configuration so experiments are reproducible and easy to tweak."""
from pathlib import Path

RANDOM_STATE = 42
TEST_SIZE = 0.25
POSITIVE_PREVALENCE = 0.15   # target share of malignant cases after subsampling
CV_FOLDS = 5
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
