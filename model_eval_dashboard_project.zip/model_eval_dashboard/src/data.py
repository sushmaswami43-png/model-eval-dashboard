"""Dataset loading and train/test splitting."""
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

from .config import POSITIVE_PREVALENCE, RANDOM_STATE, TEST_SIZE


def load_imbalanced_breast_cancer() -> tuple[pd.DataFrame, pd.Series]:
    """Load the Wisconsin Diagnostic Breast Cancer data with a screening-like imbalance.

    The raw data is 37% malignant. In population screening, malignant cases are
    rare, so malignant rows are randomly subsampled until they make up
    POSITIVE_PREVALENCE of the data. Benign rows are untouched.
    Target encoding: 1 = malignant (positive class), 0 = benign.
    """
    raw = load_breast_cancer(as_frame=True)
    X = raw.data
    y = (raw.target == 0).astype(int)  # sklearn encodes malignant as 0; flip it

    n_benign = int((y == 0).sum())
    n_malignant = round(n_benign * POSITIVE_PREVALENCE / (1 - POSITIVE_PREVALENCE))

    rng = np.random.default_rng(RANDOM_STATE)
    malignant_idx = rng.choice(y[y == 1].index, size=n_malignant, replace=False)
    keep = np.sort(np.concatenate([y[y == 0].index, malignant_idx]))
    return X.loc[keep].reset_index(drop=True), y.loc[keep].reset_index(drop=True)


def split(X: pd.DataFrame, y: pd.Series):
    """Stratified split so train and test keep the same class ratio."""
    return train_test_split(
        X, y, test_size=TEST_SIZE, stratify=y, random_state=RANDOM_STATE
    )
