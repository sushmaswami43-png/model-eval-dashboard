"""Dashboard builders: a static PNG (matplotlib) and an interactive HTML page."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

from .evaluate import ModelResult

LABELS = ["Benign", "Malignant"]
COLORS = ["#2a6fdb", "#e07b00"]


def save_static_dashboard(results: list[ModelResult], table, path) -> None:
    """One figure: confusion matrices, ROC curves, and the metrics table."""
    n = len(results)
    fig = plt.figure(figsize=(5 * n + 1, 10))
    grid = fig.add_gridspec(2, n + 1, height_ratios=[1, 0.55])

    for i, r in enumerate(results):
        ax = fig.add_subplot(grid[0, i])
        sns.heatmap(r.confusion, annot=True, fmt="d", cmap="Blues", cbar=False,
                    xticklabels=LABELS, yticklabels=LABELS, ax=ax, annot_kws={"size": 16})
        ax.set(title=f"{r.name}\nConfusion matrix (threshold 0.5)",
               xlabel="Predicted", ylabel="Actual")

    ax = fig.add_subplot(grid[0, n])
    for r, color in zip(results, COLORS):
        ax.plot(r.fpr, r.tpr, color=color, lw=2,
                label=f"{r.name} (AUC={r.metrics['ROC-AUC']:.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Chance")
    ax.set(title="ROC curves", xlabel="False positive rate", ylabel="True positive rate")
    ax.legend(loc="center right", fontsize=8)

    ax = fig.add_subplot(grid[1, :])
    ax.axis("off")
    cells = ax.table(cellText=table.values, rowLabels=table.index, colLabels=table.columns,
                     loc="center", cellLoc="center")
    cells.auto_set_font_size(False)
    cells.set_fontsize(13)
    cells.scale(1, 2.2)
    ax.set_title("Metrics comparison (test set)", fontsize=13, pad=0)

    fig.suptitle("Model Evaluation Dashboard - Breast Cancer Screening", fontsize=16)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>Model Evaluation Dashboard</title>
<style>
 body{font-family:system-ui,sans-serif;margin:24px;color:#1b1f24;background:#fafbfc}
 h1{margin:0 0 4px} .sub{color:#57606a;margin-bottom:20px}
 .row{display:flex;flex-wrap:wrap;gap:20px;margin-bottom:20px}
 .card{background:#fff;border:1px solid #d8dee4;border-radius:10px;padding:16px}
 table{border-collapse:collapse} th,td{padding:6px 12px;text-align:center;border-bottom:1px solid #eaeef2}
 th{background:#f3f5f7} td.best{font-weight:700;color:#1a7f37}
 .cm{display:grid;grid-template-columns:auto 90px 90px;gap:4px;align-items:center;text-align:center}
 .cell{height:70px;display:flex;align-items:center;justify-content:center;font-size:22px;border-radius:6px}
 .lbl{font-size:12px;color:#57606a} input[type=range]{width:320px}
</style></head><body>
<h1>Model Evaluation Dashboard</h1>
<div class="sub">__SUBTITLE__</div>
<div class="row">
 <div class="card"><h3>Metrics comparison (threshold <span id="thv1">0.50</span>)</h3><table id="tbl"></table></div>
 <div class="card"><h3>ROC curves</h3><canvas id="roc" width="360" height="360"></canvas></div>
</div>
<div class="card" style="margin-bottom:20px">
 <h3>Decision threshold</h3>
 <input id="th" type="range" min="0.05" max="0.95" step="0.01" value="0.5">
 <b id="thv2">0.50</b>
 <div class="lbl">Lower = catch more malignant cases (fewer false negatives, more false alarms).</div>
</div>
<div class="row" id="cms"></div>
<script>
const D = __DATA__;
const METRICS = ["Precision","Recall","F1-score"];
const colors = ["#2a6fdb","#e07b00"];

function counts(m, t){
  let tp=0,fp=0,tn=0,fn=0;
  D.y_true.forEach((y,i)=>{const p=m.scores[i]>=t?1:0;
    if(y&&p)tp++;else if(!y&&p)fp++;else if(!y&&!p)tn++;else fn++;});
  return {tp,fp,tn,fn};
}
function summary(c){
  const pr=c.tp+c.fp?c.tp/(c.tp+c.fp):0, rc=c.tp+c.fn?c.tp/(c.tp+c.fn):0;
  return {"Precision":pr,"Recall":rc,"F1-score":pr+rc?2*pr*rc/(pr+rc):0};
}
function render(){
  const t=+document.getElementById("th").value;
  ["thv1","thv2"].forEach(id=>document.getElementById(id).textContent=t.toFixed(2));
  const rows=D.models.map(m=>({m,s:summary(counts(m,t))}));
  let h="<tr><th>Model</th>"+METRICS.map(k=>"<th>"+k+"</th>").join("")+"<th>ROC-AUC</th></tr>";
  rows.forEach(r=>{h+="<tr><td>"+r.m.name+"</td>"+METRICS.map(k=>{
    const best=rows.every(o=>o.s[k]<=r.s[k]);
    return "<td class='"+(best?"best":"")+"'>"+r.s[k].toFixed(3)+"</td>";}).join("")+
    "<td>"+r.m.auc.toFixed(3)+"</td></tr>";});
  document.getElementById("tbl").innerHTML=h;
  document.getElementById("cms").innerHTML=rows.map(r=>{
    const c=counts(r.m,t), mx=Math.max(c.tp,c.fp,c.tn,c.fn,1);
    const cell=(v,hue)=>"<div class='cell' style='background:hsla("+hue+",70%,45%,"+(0.12+0.7*v/mx)+")'>"+v+"</div>";
    return "<div class='card'><h3>"+r.m.name+" - confusion matrix</h3><div class='cm'>"+
     "<span></span><span class='lbl'>Pred benign</span><span class='lbl'>Pred malignant</span>"+
     "<span class='lbl'>Actual benign</span>"+cell(c.tn,215)+cell(c.fp,30)+
     "<span class='lbl'>Actual malignant</span>"+cell(c.fn,30)+cell(c.tp,215)+"</div></div>";}).join("");
}
function drawRoc(){
  const cv=document.getElementById("roc"),g=cv.getContext("2d"),p=40,w=cv.width-2*p,h=cv.height-2*p;
  g.font="12px system-ui";g.strokeStyle="#999";g.strokeRect(p,p,w,h);
  g.setLineDash([4,4]);g.beginPath();g.moveTo(p,p+h);g.lineTo(p+w,p);g.stroke();g.setLineDash([]);
  g.fillStyle="#333";g.fillText("False positive rate",p+w/2-45,cv.height-8);
  g.save();g.translate(12,p+h/2+40);g.rotate(-Math.PI/2);g.fillText("True positive rate",0,0);g.restore();
  D.models.forEach((m,k)=>{g.strokeStyle=colors[k];g.lineWidth=2;g.beginPath();
    m.fpr.forEach((x,i)=>{const X=p+x*w,Y=p+h-m.tpr[i]*h;i?g.lineTo(X,Y):g.moveTo(X,Y);});g.stroke();
    g.fillStyle=colors[k];g.fillText(m.name+" (AUC "+m.auc.toFixed(3)+")",p+w-190,p+h-40+k*16);});
}
document.getElementById("th").addEventListener("input",render);
drawRoc();render();
</script></body></html>"""


def save_interactive_dashboard(results: list[ModelResult], y_test, subtitle, path) -> None:
    """Self-contained HTML (no external libraries); threshold slider recomputes metrics."""
    payload = {
        "y_true": [int(v) for v in y_test],
        "models": [{
            "name": r.name,
            "auc": float(r.metrics["ROC-AUC"]),
            "scores": [round(float(s), 4) for s in r.y_score],
            "fpr": [round(float(v), 4) for v in r.fpr],
            "tpr": [round(float(v), 4) for v in r.tpr],
        } for r in results],
    }
    html = _HTML.replace("__DATA__", json.dumps(payload)).replace("__SUBTITLE__", subtitle)
    path.write_text(html, encoding="utf-8")
