"""Build the assignment report PDF from the generated outputs."""
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

ROOT = Path(__file__).parent
OUT = ROOT / "outputs"
S = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=S["BodyText"], fontSize=10.5, leading=15)
CODE = ParagraphStyle("code", parent=S["Code"], fontSize=7.2, leading=8.6)


def para(text, style=BODY):
    return Paragraph(text, style)


def bullets(items):
    return [para("&bull; " + t) for t in items]


def metrics_flowable():
    df = pd.read_csv(OUT / "metrics.csv", index_col=0)
    data = [["Model"] + list(df.columns)] + [[i] + [f"{v:.3f}" for v in row]
                                              for i, row in zip(df.index, df.values)]
    t = Table(data, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2a6fdb")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


story = [
    para("Evaluation Dashboard for Model Cards Using Real Data", S["Title"]),
    para("Machine Learning Assignment Report", S["Heading3"]),
    Spacer(1, 8),

    para("1. Objective", S["Heading2"]),
    para("Build an evaluation dashboard that turns classifier outputs into decision-ready "
         "insight: train two models on an imbalanced real-world dataset, report precision, "
         "recall, F1-score and ROC-AUC, visualise confusion matrices and ROC curves, and "
         "justify which model to prefer."),

    para("2. Dataset and why it was chosen", S["Heading2"]),
    para("<b>Dataset:</b> Wisconsin Diagnostic Breast Cancer (569 patients, 30 numeric features "
         "computed from fine-needle-aspirate images; bundled with scikit-learn, so the project "
         "runs offline). <b>Positive class:</b> malignant."),
    para("<b>Why it fits:</b> it is real clinical data, and the cost of errors is clearly "
         "asymmetric. A missed cancer (false negative) is far worse than an unnecessary "
         "follow-up test (false positive). That makes accuracy a poor yardstick and forces the "
         "precision/recall trade-off the assignment is about."),
    para("<b>Making it imbalanced (disclosed):</b> the original data is 37% malignant, which "
         "is only mildly imbalanced. Because malignant cases are rare in population screening, "
         "malignant rows were randomly subsampled (fixed seed) to 15% prevalence: 357 benign + "
         "63 malignant = 420 samples. Benign rows were not changed. Results therefore describe "
         "a screening-like setting, not the original sample. A model predicting 'benign' for "
         "everyone would score 85% accuracy yet catch no cancers."),

    para("3. Method", S["Heading2"]),
    *bullets([
        "<b>Split:</b> stratified 75/25 train/test (315 / 105 patients; 16 malignant in test).",
        "<b>Imbalance handling:</b> cost-sensitive learning via <i>class_weight</i> "
        "('balanced' for Logistic Regression, 'balanced_subsample' for Random Forest). "
        "No test data is resampled, so evaluation stays honest.",
        "<b>Models:</b> Logistic Regression (with standard scaling, an interpretable linear "
        "baseline) and Random Forest (300 trees, a non-linear ensemble).",
        "<b>Metrics:</b> precision, recall, F1-score at threshold 0.5; ROC-AUC and PR-AUC "
        "(threshold-independent); 5-fold stratified CV ROC-AUC to check split luck.",
    ]),
    Spacer(1, 6),

    para("4. Results", S["Heading2"]),
    metrics_flowable(),
    Spacer(1, 6),
    para("5-fold CV ROC-AUC: Logistic Regression 0.976 &plusmn; 0.021, Random Forest "
         "0.980 &plusmn; 0.030."),
    para("Confusion matrices at threshold 0.5 (test set): Logistic Regression TN=86, FP=3, "
         "FN=0, TP=16; Random Forest TN=89, FP=0, FN=3, TP=13."),
    PageBreak(),
    para("5. Dashboard", S["Heading2"]),
    Image(str(OUT / "dashboard.png"), width=17 * cm, height=17 * cm * 1050 / 1150,
          kind="proportional"),
    para("An interactive version (<i>outputs/dashboard.html</i>) adds a decision-threshold "
         "slider that recomputes the confusion matrices, precision, recall and F1 live, so a "
         "stakeholder can see the false-negative/false-positive trade-off directly."),

    para("6. Analysis: which model to prefer", S["Heading2"]),
    para("<b>Recommendation: Logistic Regression for a screening use case.</b>"),
    *bullets([
        "<b>It misses no cancers.</b> Recall is 1.00 (0 false negatives) versus 0.81 for the "
        "Random Forest, which missed 3 of 16 malignant patients. In screening, a missed "
        "diagnosis is the costly error.",
        "<b>The price is modest.</b> Logistic Regression raised 3 false alarms (precision "
        "0.84); the Random Forest raised none (precision 1.00). Three extra follow-up tests "
        "are a much smaller harm than three missed cancers.",
        "<b>Better ranking quality on this split.</b> ROC-AUC 0.999 vs 0.992 and PR-AUC 0.996 "
        "vs 0.963. PR-AUC is the more informative of the two under imbalance.",
        "<b>Interpretable.</b> Coefficients can be inspected and explained to clinicians, "
        "which matters for a model card.",
    ]),
    para("<b>When the Random Forest would be preferred:</b> if false positives were very "
         "costly (for example invasive biopsies for every flag) it would win on precision. "
         "Its threshold can also be lowered to recover recall, and the slider shows how."),
    para("<b>Caveats.</b> The test set holds only 16 malignant cases, so one patient moves "
         "recall by about 6 points. Cross-validated AUC is nearly identical (0.976 vs 0.980, "
         "each with a standard deviation of 0.02 to 0.03), so the models are statistically "
         "close on ranking ability. The preference rests mainly on the error trade-off at the "
         "chosen threshold, not on a decisive AUC gap. Prevalence was set artificially; before "
         "any real use the threshold must be re-validated on data with the true prevalence."),

    para("7. How to run", S["Heading2"]),
    Preformatted("pip install -r requirements.txt\npython main.py        # trains, evaluates, builds dashboard\n"
                 "python make_pdf.py    # regenerates this report", CODE),
    PageBreak(),
    para("Appendix: Source code", S["Heading2"]),
]

for rel in ["main.py", "src/config.py", "src/data.py", "src/models.py", "src/evaluate.py"]:
    story += [para(f"<b>{rel}</b>"), Preformatted((ROOT / rel).read_text(), CODE), Spacer(1, 8)]
story += [para("<b>src/dashboard.py</b> (static dashboard function; HTML template omitted for "
               "brevity, see project files)")]
dash = (ROOT / "src/dashboard.py").read_text()
story.append(Preformatted(dash[:dash.index('_HTML = """')] +
                          dash[dash.index("def save_interactive_dashboard"):], CODE))

SimpleDocTemplate(str(OUT / "Model_Evaluation_Dashboard_Report.pdf"), pagesize=A4,
                  leftMargin=2 * cm, rightMargin=2 * cm, topMargin=2 * cm,
                  bottomMargin=2 * cm, title="Evaluation Dashboard for Model Cards").build(story)
print("PDF written")
